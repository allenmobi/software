//  Created by Pieter Omvlee on 09/04/2015.
//  Copyright (c) 2015 Bohemian Coding. All rights reserved.

BOOL BCFloatEqualWithMargin(CGFloat a, CGFloat b, CGFloat margin);
BOOL BCFloatEqual(CGFloat a, CGFloat b);

/// Returns YES if \p a is greater than \p b by \p margin, otherwise NO
BOOL BCFloatGreaterThanWithMargin(CGFloat a, CGFloat b, CGFloat margin);
/// Returns YES if \p a is less than \p b by \p margin, otherwise NO
BOOL BCFloatLessThanWithMargin(CGFloat a, CGFloat b, CGFloat margin);

/**
 Returns a float rounded clamped to a given range as defined by \code min and \code max. In other words; the returned value is guaranteed to be no smaller than min and no bigger than max
 We assert that min < max
 */
CGFloat BCFloatClamp(CGFloat value, CGFloat min, CGFloat max);
